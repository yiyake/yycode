FGviewer: an online visualization tool for functional features of human fusion genes
系统构建负责人
2018.10 至 2019.12
项目介绍：构建人类基因融合的可视化工具。
工作内容：利用开源的人类基因数据，针对基因融合事件，利用网页开发技术实现在DNA，RNA和蛋白质水平在基因融合时候相关数据的变化情况的动态交互的网页系统。
成果：FGviewer在Nucleic Acids Research发表表
成果展示：https://ccsmweb.uth.edu/FGviewer/

我的指职责内容：
处理基因数据；
数据库使用；
网页系统前后端搭建；
搜索系统实现数据读取并绘制实现可视化。

所用技术：
h5、CSS、MySQL、JS、Tornado网页技术。