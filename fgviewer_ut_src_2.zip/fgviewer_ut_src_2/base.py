import os
import urllib

import tornado.web

class BaseHandler(tornado.web.RequestHandler):
    def prepare(self):
        self.clear_header('Server')
        self.set_header('X-FRAME-OPTIONS', 'SAMEORIGIN')
        self.set_header('X-XSS-Protection', '1; mode=block')
        self.set_header('X-Content-Type-Options', 'nosniff')
        self.set_header('Strict-Transport-Security', 'max-age=31536000; includeSubdomains')

    def check_permission(self, action):
        user = self.get_current_user()
        admin = self.is_admin_user()
        if action in self.perm_public or (user and action in self.perm_user) or (admin and action in self.perm_admin):
            pass # ok
        else:
            self.raise403()

    def raise400(self, msg=None):
        raise tornado.web.HTTPError(400, msg or 'Invalid request')

    def raise401(self, msg=None):
        raise tornado.web.HTTPError(401, msg or 'Not enough permissions to perform this action')

    def raise403(self, msg=None):
        raise tornado.web.HTTPError(403, msg or 'Not enough permissions to perform this action')

    def raise404(self, msg=None):
        raise tornado.web.HTTPError(404, msg or 'Object not found')

    def raise422(self, msg=None):
        raise tornado.web.HTTPError(422, msg or 'Invalid request')

    def raise500(self, msg=None):
        raise tornado.web.HTTPError(500, msg or 'Something is not right')
