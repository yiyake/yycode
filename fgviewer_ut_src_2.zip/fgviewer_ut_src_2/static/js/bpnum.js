var dnabpnum1='';
var dnabpnum2='';

    